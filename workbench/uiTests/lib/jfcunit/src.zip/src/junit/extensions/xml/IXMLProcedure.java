package junit.extensions.xml;

import org.w3c.dom.Element;


/**
 * IXMLProcedure Interface for containing the procedure.
 *
 * @author Kevin Wilson
 */
public interface IXMLProcedure {
    /**
     * Get the Element containing the procedure.
     * @return Element containting the procedure.
     */
    Element getElement();

    /**
     * Get the name for the test case.
     * @return name of the test case.
     */
    String getName();
}
