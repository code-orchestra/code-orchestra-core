package junit.extensions.xml;


/**
 * This class defines the common tokens which are
 * used in parsing the XML file.
 * @author Kevin Wilson
 */
public interface XMLConstants {
    /** action. */
    String ACTION = "action";

    /** actualobj. */
    String ACTUALOBJ = "actualobj";

    /** actualrefid. */
    String ACTUALREFID = "actualrefid";

    /** add. */
    String ADD = "add";

    /** assertenabled. */
    String ASSERTENABLED = "assertenabled";

    /** asertequals. */
    String ASSERTEQUALS = "assertequals";

    /** assertnotequals. */
    String ASSERTNOTEQUALS = "assertnotequals";

    /** assertnotnull. */
    String ASSERTNOTNULL = "assertnotnull";

    /** assertnotsame. */
    String ASSERTNOTSAME = "assertnotsame";

    /** assertnull. */
    String ASSERTNULL = "assertnull";

    /** assertsame. */
    String ASSERTSAME = "assertsame";

    /** call. */
    String CALL = "call";

    /** case. */
    String CASE = "case";

    /** choose. */
    String CHOOSE = "choose";

    /** classname. */
    String CLASSNAME = "classname";

    /** column. */
    String COLUMN = "column";

    // Assert

    /** confirm. */
    String CONFIRM = "confirm";

    /** debug. */
    String DEBUG = "debug";

    /** default. */
    String DEFAULT = "default";

    /** delimiter. */
    String DELIMITER = "delimiter";

    /** dialog. */
    String DIALOG = "dialog";

    /** dump. */
    String DUMP = "dump";

    /** echo. */
    String ECHO = "echo";

    /** enabled. */
    String ENABLED = "enabled";

    /** encoding. */
    String ENCODING = "encoding";

    /** evaluate. */
    String EVALUATE = "evaluate";

    /** expectedobj. */
    String EXPECTEDOBJ = "expectedobj";

    /** expectedrefid. */
    String EXPECTEDREFID = "expectedrefid";

    /** fail. */
    String FAIL = "fail";

    /** file. */
    String FILE = "file";

    /** focus. */
    String FOCUS = "focus";

    /** foreach. */
    String FOREACH = "foreach";

    /** id. */
    String ID = "id";

    /** index. */
    String INDEX = "index";

    /** JFCFileLocation. */
    String JFCFILELOC = "JFCFileLocation";

    /** lessthan. */
    String LESSTHAN = "lessthan";

    // Types of looping

    /** listitem. */
    String LISTITEM = "listitem";

    /** log. */
    String LOG = "log";

    /** mark. */
    String MARK = "mark";

    /** message. */
    String MESSAGE = "message";

    /** method. */
    String METHOD = "method";

    /** mode. */
    String MODE = "mode";

    /** name. */
    String NAME = "name";

    /** otherwise. */
    String OTHERWISE = "otherwise";

    /** pathrefid. */
    String PATHREFID = "pathrefid";

    /** procedure. */
    String PROCEDURE = "procedure";

    /** property. */
    String PROPERTY = "property";

    /** recursive. */
    String RECURSIVE = "recursive";

    /** refid. */
    String REFID = "refid";

    /** relative. */
    String RELATIVE = "relative";

    /** remove. */
    String REMOVE = "remove";

    /** row. */
    String ROW = "row";

    /** save. */
    String SAVE = "save";

    /** stderr. */
    String STDERR = "stderr";

    /** stdout. */
    String STDOUT = "stdout";

    /** stopwatch. */
    String STOPWATCH = "stopwatch";

    /** suite. */
    String SUITE = "suite";

    /** switch. */
    String SWITCH = "switch";

    /** tablecell. */
    String TABLECELL = "tablecell";

    /** taghandlers. */
    String TAGHANDLERS = "taghandlers";

    /** tagname. */
    String TAGNAME = "tagname";

    /** test. */
    String TEST = "test";

    /** type. */
    String TYPE = "type";

    /** useRE. */
    String USERE = "useRE";

    /** value. */
    String VALUE = "value";

    /** when. */
    String WHEN = "when";

    /** while. */
    String WHILE = "while";
}
