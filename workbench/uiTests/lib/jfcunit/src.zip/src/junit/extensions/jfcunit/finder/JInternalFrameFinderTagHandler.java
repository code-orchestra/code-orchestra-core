package junit.extensions.jfcunit.finder;

import junit.extensions.xml.IXMLTestCase;
import junit.extensions.xml.XMLException;

import org.w3c.dom.Element;


/**
 * This is a extension of the findTagHandler element. Where the
 * finder specified is FrameFinder.
 *
 * <h3>Description</h3>
 * <p>
 *   This creates a JInternalFrameFinder and executes the find.
 * </p>
 * <h3>Tag Name</h3>
 * JInternalFrameFinder
 * <h3>Parameters</h3>
 * <table border="1" cellpadding="2" cellspacing="0">
 *   <tr>
 *     <td valign="top"><b>Attribute</b></td>
 *     <td valign="top"><b>Description</b></td>
 *     <td align="center" valign="top"><b>Required</b></td>
 *     <td valign="top"><b>Default</b></td>
 *     <td valign="top"><b>Values</b></td>
 *   </tr>
 *   <tr>
 *     <td valign="top">finder</td>
 *     <td valign="top">For this element the type must be set to FrameFinder</td>
 *     <td valign="top" align="center">Yes</td>
 *     <td valign="top">N/A</td>
 *     <td valign="top">N/A</td>
 *   </tr>
 *   <tr>
 *     <td valign="top">id</td>
 *     <td valign="top">Id for the object found.</td>
 *     <td valign="top" align="center">Yes</td>
 *     <td valign="top">N/A</td>
 *     <td valign="top">String</td>
 *   </tr>
 *   <tr>
 *     <td valign="top">title</td>
 *     <td valign="top">The title of the frame to be found.</td>
 *     <td valign="top" align="center">Yes</td>
 *     <td valign="top">None</td>
 *     <td valign="top">Regular expression defining the title.</td>
 *   </tr>
 *   <tr>
 *     <td valign="top">caseindependent</td>
 *     <td valign="top">Ignore the case if true</td>
 *     <td valign="top" align="center">No</td>
 *     <td valign="top">false</td>
 *     <td valign="top">true/false</td>
 *   </tr>
 * </table>
 * <h3>Example</h3>
 * <blockquote><pre>
 * &lt;find
 *    finder=&quot;JInternalFrameFinder&quot;
 *    id=&quot;MyFrame&quot;
 *    title=&quot;^My frame$&quot;
 * /&gt;
 * </pre></blockquote>
 * <p>
 * The above finds the first frame with
 * a complete title &quot;My frame&quot;
 * </p>
 * @see junit.extensions.jfcunit.finder.JInternalFrameFinder
 * @author Kevin Wilson
 */
public class JInternalFrameFinderTagHandler extends BaseFindTagHandler {
    /**
     * Constructor for ComponentFinderTagHandler.
     *
     * @param element     The element to be processed
     * @param testCase    The IXMLTestCase that uses this element
     */
    public JInternalFrameFinderTagHandler(final Element element,
        final IXMLTestCase testCase) {
        super(element, testCase);
    }

    /**
     * @see junit.extensions.xml.elements.AbstractTagHandler#processElement()
     */
    public void processElement() throws XMLException {
        validateElement();

        JInternalFrameFinder finder = new JInternalFrameFinder(
                getTitle(),
                getCaseIndependent());
        finder.setWait(getWait());
        finder.setDebug(getXMLTestCase().getDebug());

        String className = getClassName();
        Class cls = null;
        try {
            cls = Class.forName(className);
        } catch (ClassNotFoundException cnfe) {
            throw new XMLException("Could not locate class:"
                                    + className,
                                    cnfe,
                                    getElement(),
                                    getXMLTestCase().getPropertyCache());
        }
        finder.setComponentClass(cls);
        find(finder);
    }

    /**
     * @see junit.extensions.xml.elements.AbstractTagHandler#validateElement()
     */
    public void validateElement() throws XMLException {
        // do the default validations from the super class
        super.validateElement();

        // reqd attribute: class
        checkRequiredAttribute(TITLE);
    }
}
